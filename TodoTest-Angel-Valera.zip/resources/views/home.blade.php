@extends('layouts.app')

@section('content')
<div class="container">
    <todo-page-component></todo-page-component>
</div>
@endsection
